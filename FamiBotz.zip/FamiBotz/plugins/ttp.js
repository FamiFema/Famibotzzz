import api = require('api-dylux');
let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `Masukan Text`
  await m.reply('Tunggu Sebentar...')
  api.ttp(text)
    let stiker = await sticker(false, meme, global.stickpack, global.wm)
    if (stiker) await conn.sendFile(m.chat, stiker, '', m, '', { asSticker: 1 })
}        
handler.command = ['ttp']
handler.help = ['ttp (text)']
handler.tags = ['sticker']

export default handler