import { Configuration, OpenAIApi } = require("openai");
import fetch = require("node-fetch");
import { generateWAMessageFromContent } = require("@adiwajshing/baileys");
import fs = require("fs");

let handler = async (m, { conn, usedPrefix, command, text }) => {
    if (!text) throw new Error(`Chat dengan AI.\n\nContoh:\n${usedPrefix}${command} Halo?`);
const configuration = new Configuration({
    apiKey: '${global.openai}'
});
const openai = new OpenAIApi(configuration);
        const response = await openai.createCompletion({
            model: "text-davinci-003",
            prompt: text,
            temperature: 0,
            max_tokens: 3000,
            top_p: 1,
            frequency_penalty: 0.5,
            presence_penalty: 0
        });
    conn.reply(m.chat, `${response.data.choices[0].message.content}`, m);

  } catch (error) {
    console.log(error);
    if (error.response) {
      console.log(error.response.status);
      console.log(error.response.data);
      conn.reply(m.chat, `${error.response.status}\n\n${error.response.data}`, m);
    } else {
      conn.reply(m.chat, `${error.message}`, m);
    }
  }
}

handler.help = ['openai']
handler.tags = ['ai']
handler.command = /^(chatai|ai|openai)$/i
handler.premium = true

module.exports = handler