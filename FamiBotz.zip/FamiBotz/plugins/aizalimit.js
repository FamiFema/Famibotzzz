import fetch from "node-fetch";
import { generateWAMessageFromContent } from "@adiwajshing/baileys";
import fs from 'fs';
import { Configuration, OpenAIApi } from 'openai';
const rewards = {
    limit: 500,
  }
let handler = async (m, { conn, usedPrefix, command, text }) => {
  try {
    let user = global.db.data.users[m.sender]
    if (new Date - user.limit < limit) throw `limit lu kagak cukup🗿`
    let text = ''
    for (let reward of Object.keys(rewards)) {
      if (!(reward in user)) continue
      user[reward] -= rewards[reward]
      text -= `*-${rewards[reward]}* ${global.rpg.emoticon(reward)}${reward}\n`}
const openai = new OpenAIApi(configuration);
let (!text) throw new Error(`Chat with AI.\n\nExample:\n${prefix + command} APA ITU AKAZA`)
const configuration = new Configuration({
apiKey: global.openai,
});
const openai = new OpenAIApi(configuration);
const response = await openai.createCompletion({
model: "gpt-2",
prompt: text,
temperature: 0.3,
max_tokens: 2000,
top_p: 1.0,
frequency_penalty: 0.0,
presence_penalty: 0.0,
});
m.reply(`${response.data.choices[0].text}`);
} catch (error) {
if (error.response) {
console.log(error.response.status);
console.log(error.response.data);
console.log(`${error.response.status}\n\n${error.response.data}`);
} else {
console.log(error);
m.reply("apikey dah ilang :"+ error.message);
}
}
handler.help = ['zalimit <pertanyaan>']
handler.tags = ['ai']
handler.command = /^(zalimit)$/i
handler.limit = true
handler.register = true

export default handler