const Apikey = "${global.openai}";
import {
	Configuration,
	OpenAIApi
} from 'openai';

const config = new Configuration({
	apiKey: Apikey
});

const openai = new OpenAIApi(config);

export async function before(m) {
	let setting = global.db.data.settings[this.user.jid];
	let isAi = m.text.toLowerCase().split(' ')[0] || '';
	let text = m.text.slice(isAi.length + 1, m.text.length);
	if (!setting.chatAi || !/ai/.test(isAi)) return;
	try {
		let name = await this.getName(m.sender);
		const res = await openai.createCompletion({
			model: "text-davinci-003",
			prompt: text,
			temperature: 0.6,
			max_tokens: 256,
			top_p: 1,
			frequency_penalty: 0,
			presence_penalty: 0.6,
			stop: [name, "Ai:"],
		});
		if (res.status !== 200) throw res.statusText;
		 await this.reply(m.chat, res?.data?.choices[0]?.text, m, { render: true, thum: '${global.thumb}', source: sgh, iklan: true, body: 'AKAZA BOT AI' })
	} catch (e) {
		console.error(e);
	}
}