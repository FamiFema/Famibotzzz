echo "starting"

sleep 3
echo "start ini hanya untuk pengguna replit dan panel"
echo ":::::::::::::::::::::::::::::::::" sleep 2
echo ":::::::::::::::::::::::::::::::::" sleep 1
echo ":::::         AKAZA         :::::" sleep 1
echo ":::::           MD          :::::" sleep 1
echo ":::::   :::::      :::::    :::::" sleep 1
echo ":::::   :::::      :::::    :::::" sleep 1
echo ":::::    BOT NO COUNTER     :::::" sleep 1
echo ":::::     ::::::::::::      :::::" sleep 1
echo ":::::     ::::::::::::      :::::" sleep 1
echo ":::::                       :::::" sleep 1
echo ":::::::::::::::::::::::::::::::::" sleep 1
echo ":::::::::::::::::::::::::::::::::" sleep 1


echo ".       jan lupa sub yt gw"


node index.js


